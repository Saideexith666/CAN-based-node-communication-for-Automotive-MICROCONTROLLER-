/*
 * File:   main.c
 * Author: DELL INSPIRON
 *
 * Created on 6 October, 2025, 8:38 AM
 */


#include <xc.h>
#include <stdio.h>
#include "digital_keypad.h"
#include "adc.h"
#include "msg_id.h"
#include "can.h"
#include "ecu1_sensor.h"

void init_config(void)
{
    TRISB0 = 0;
    TRISB1 = 0;
    TRISB6 = 0;
    TRISB7 = 0;
    PORTB = 0X00;
    
    init_digital_keypad();
    init_adc();
    init_can();
}


void main(void) {
    
    int rpm,indi;
    init_config();
    
    
    while (1) {

       rpm = get_rpm();
       char RPM[5];
       sprintf(RPM, "%u", rpm);
       can_transmit(RPM_MSG_ID,RPM,4);
        
       indi = process_indicator();
       can_transmit(INDICATOR_MSG_ID,&indi,1);        
    }
}
