/*
 * File:   ecu1_sensor.c
 * Author: DELL INSPIRON
 *
 * Created on 6 October, 2025, 8:38 AM
 */

#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"

uint16_t get_rpm()
{
    unsigned short adc_value;
    uint16_t RPM;
    //Implement the rpm function
    adc_value = read_adc(CHANNEL4);
    RPM = (adc_value * 5.88);
    if(RPM > 6000)
    {
        RPM = 6000;
    }
    return RPM;
    
}

IndicatorStatus process_indicator()
{
    unsigned char key;
    static unsigned int flag = 0,flag1 = 0;
    static unsigned long delay = 0;
    int indi;
    //Implement the indicator function
    
    key = read_digital_keypad(STATE_CHANGE);
        if (key == SWITCH1){
               flag = 1;
        }  
        else if (key == SWITCH2){
            flag = 2;
        }
        else if (key == SWITCH3){
            flag = 3;
        }      
        else if (key == SWITCH4){
            flag = 4;
        }
            
        
        if (flag != flag1)
        {
            PORTB = 0X00;
            flag1 = flag;
        }

        if (flag == 1){
            if(delay++ == 50)
            {
                RB0 = !RB0;
                RB1 = !RB1;
                delay = 0;
            }
        }
            
        else if (flag == 2)
        {
            if(delay++ == 50)
            {
                RB6 = !RB6;
                RB7 = !RB7;
                delay = 0;
            }
        }
        else if (flag == 3)
        {
            if(delay++ == 50)
            {
                RB0 = !RB0;
                RB1 = !RB1;
                RB6 = !RB6;
                RB7 = !RB7;
                
                delay = 0;
            }
        }
        else if (flag == 4){
            PORTB = 0X00;
        }
        else
        {
            PORTB = 0x00; // all LEDs OFF when no key
        }
    
    return flag;
}
