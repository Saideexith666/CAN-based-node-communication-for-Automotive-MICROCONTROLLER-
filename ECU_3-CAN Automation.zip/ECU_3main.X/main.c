 /*
 * File:   main.c
 * Author: DELL INSPIRON
 *
 * Created on 30 September, 2025, 7:56 AM
 */

#include <xc.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include <stdio.h>
#include<string.h>

#define _XTAL_FREQ      20000000

void init_config(void) {
    init_clcd();
    init_can();
}

void main(void) {
    init_config();
    clcd_print("RPM", LINE1(0));
    clcd_print("SPD", LINE1(5));
    clcd_print("GR", LINE1(10));
    clcd_print("IND", LINE1(13));
    clcd_print("OFF", LINE2(13));


    uint8_t indicator;
    uint16_t msg_id;
    uint8_t len;
    uint16_t rpm_msg_id;
    uint8_t data[5];
    uint8_t rpm_len;
    uint8_t buffer[5] = {0};
    unsigned long int delay = 0;
    uint8_t blink_state = 0;

    while (1) {

        can_receive(&msg_id, data, &len);

        switch (msg_id) {

//            case INDICATOR_MSG_ID:
//            {
//                uint8_t indi = data[0];
//
//                if (indi == 1) {
//                    clcd_print("<--", LINE2(13));
//                } else if (indi == 2) {
//                    clcd_print("-->", LINE2(13));
//                } else if (indi == 3) {
//                    clcd_print("<->", LINE2(13));
//                } else if (indi == 4) {
//                    clcd_print("OFF", LINE2(13));
//                } 
//                break;
//            }
            
              case INDICATOR_MSG_ID:
            {
                uint8_t indi = data[0];

                if (indi == 1 || indi == 2 || indi == 3) {
                    // Blink logic for half second
                    if (blink_state == 0) {
                        if (indi == 1) {
                            clcd_print("<--", LINE2(13));
                        } else if (indi == 2) {
                            clcd_print("-->", LINE2(13));
                        } else if (indi == 3) {
                            clcd_print("<->", LINE2(13));
                        }
                        blink_state = 1;
                    } else {
                        // Clear symbol (blank space)
                        clcd_print("   ", LINE2(13));
                        blink_state = 0;
                    }
                    __delay_ms(500);
                } 
                else if (indi == 4) {
                    clcd_print("OFF", LINE2(13));
                }
                break;
            }
            case RPM_MSG_ID:
            {
                data[4] = '\0';
                int rpm = atoi(data);
                char buf[5];
                sprintf(buf, "%4d", rpm);
                clcd_print(buf, LINE2(0));
                break;
            }
            case GEAR_MSG_ID:
            {
                data[len] = '\0'; // Null-terminate received gear string
                clcd_print((char *) data, LINE2(10)); // Display gear name (GN?GR)
                break;
            }
            case SPEED_MSG_ID:
            {
                data[3] = '\0';
                int speed = atoi(data);
                char buf1[5];
                sprintf(buf1, "%3d", speed);
                clcd_print(buf1, LINE2(5));
                break;
            }

        }
    }
}