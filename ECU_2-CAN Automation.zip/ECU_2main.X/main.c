/*
 * File:   main.c
 * Author: DELL INSPIRON
 *
 * Created on 29 September, 2025, 11:45 AM
 */
#include<stdio.h>
#include <xc.h>
#include <stdint.h>
#include "adc.h"
#include "clcd.h"
#include "can.h"
#include "ecu2_sensor.h"   // for get_speed, get_gear_pos
#include "msg_id.h"

// CONFIG

#define _XTAL_FREQ      20000000

char *GEAR[] = {"GN", "G1", "G2", "G3", "G4", "G5", "GR"};

static void init_config(void) {
    TRISB = 0x80; // PORTB as output (optional LEDs)
    PORTB = 0x00;

//    init_clcd();
    init_digital_keypad();
    init_adc(); // initialize ADC (for potentiometer)
    init_can(); // initialize CAN
}

void main(void) {
    
    int spd,gear;
    init_config();
    
    while (1) {
        
        spd = get_speed();
        char SPEED[5];
        sprintf(SPEED, "%u", spd);
        can_transmit(SPEED_MSG_ID, SPEED,3);
        
        gear = get_gear_pos();
//        sprintf(GEAR, "%s", GEAR[gear]);
        can_transmit(GEAR_MSG_ID, GEAR[gear], 2); 

        __delay_ms(100);
    }
}

