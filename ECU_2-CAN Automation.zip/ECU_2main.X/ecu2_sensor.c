/*
 * File:   ecu2_sensor.c
 * Author: DELL INSPIRON
 *
 * Created on 29 September, 2025, 11:45 AM
 */

#include "ecu2_sensor.h"
#include "adc.h"
#include "digital_keypad.h"

/* Maintain gear state globally */
static unsigned char gear = 0;   // Global gear index (0 = GN, 6 = GR)
char *GEAR[] = {"GN", "G1", "G2", "G3", "G4", "G5", "GR"};

uint16_t get_speed()
{
    unsigned short adc_reg_val;
    int SPEED;

    /* Read ADC channel 4 (pot/sensor for speed) */
    adc_reg_val = read_adc(SPEED_ADC_CHANNEL);
    SPEED = (adc_reg_val / 5.1272);   // scale approx 0?99

    return SPEED;
}

unsigned char get_gear_pos()
{
    unsigned char key = read_digital_keypad(STATE_CHANGE);

    if (key != ALL_RELEASED)
    {
        if (key == SWITCH1)  // Increment gear
        {
            if (gear < 6)   // Limit to GR (index 6)
            {
                gear++;
            }
        }
        else if (key == SWITCH2)  // Decrement gear
        {
            if (gear > 0)   // Limit to GN (index 0)
            {
                gear--;
            }
        }
    }

    return gear;
}
